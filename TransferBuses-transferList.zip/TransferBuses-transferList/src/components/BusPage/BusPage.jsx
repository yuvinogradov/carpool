export default function BusPage(){
 return <div className="BusPage">
   <form>
     <div className="inputsHolder">
       <input type="text" placeholder="from" />
       <input type="text" placeholder="to" />
       <input type="text" placeholder="type e-mail"/>
       <input type="text" placeholder="type price"/>
       <input type="text" placeholder=""/>
     </div>

   </form>
 </div>

}